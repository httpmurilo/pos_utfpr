package model;

public class Leitura {
}
