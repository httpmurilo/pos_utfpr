package exception;

public class VelocException extends RuntimeException{

    public VelocException(String message) {
        super(message);
    }
}
