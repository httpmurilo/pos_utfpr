package exception;

public class VeicExistException extends RuntimeException {

    public VeicExistException(String message) {
        super(message);
    }
}
