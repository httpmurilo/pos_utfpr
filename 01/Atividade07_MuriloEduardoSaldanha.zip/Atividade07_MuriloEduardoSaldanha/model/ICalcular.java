package model;

public interface ICalcular {
}
